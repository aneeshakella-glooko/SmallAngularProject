public class Product {
    private String name;
    private int inventory;
    private double price;

    public Product (String name, int inventory, double price){
        this.name = name;
        this.inventory = inventory;
        this.price = price;
    }

    public String getName(){
        return this.name;
    }

    public int getInventory(){
        return this.inventory;
    }

    public double getPrice(){
        return this.price;
    }

    public void setName (String name){
        this.name = name;
    }

    public void setInventory (int inventory){
        this.inventory = inventory;
    }

    public void setPrice (double price){
        this.price = price;
    }

    public void makePurchase(int amountToBuy){
        if (amountToBuy > inventory){
            System.out.println("Cannot Execute Purchase");
        }else if (amountToBuy >= 0 && amountToBuy < 10){
            System.out.println("Total Cost: " + amountToBuy * this.price);
            this.inventory -= amountToBuy;
        } else if (amountToBuy >= 10 && amountToBuy <= 99){
            System.out.println("Total Cost: " + amountToBuy * this.price * 0.9);
            this.inventory -= amountToBuy;
        }else{
            System.out.println("Total Cost: " + amountToBuy * this.price * 0.8);
            this.inventory -= amountToBuy;
        }
    }

    public static void main(String [] args){
        Product apple = new Product("Apple", 1000, 1.00);
        int [] arr = {7, 530, 480, 243};
        for(int i = 0; i < arr.length; i++){
            apple.makePurchase(arr[i]);
        }
    }
    
    

}
