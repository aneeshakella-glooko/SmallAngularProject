
public class Animal{

    private String color;
    private String favoriteFood;
    public int heads;
    Animal(String color, String favoriteFood, int heads){
        this.color = color;
        this.favoriteFood = favoriteFood;
        this.heads = heads;
    }

    public String getColor(){
        return this.color;
    }

    public String getFavoriteFood(){
        return this.favoriteFood;
    }

    public int getHeads(){
        return this.heads;
    }

    public void setColor(String color){
        this.color = color;
    }

    public void setFavoriteFood(String favoriteFood){
        this.favoriteFood = favoriteFood;
    }

    public void setHeads(int heads){
        this.heads = heads;
    }

    // public static void main(String [] args){
    //     Animal cheetah = new Animal("yellow", "zebras", 1);
    //     Animal ostrich = new Animal("pink", "bugs", 1);

    //     System.out.println(cheetah.getColor());
    //     System.out.println(cheetah.getFavoriteFood());
    //     System.out.println(cheetah.getHeads());
    //     System.out.println(" ");
    //     System.out.println(ostrich.getColor());
    //     System.out.println(ostrich.getFavoriteFood());
    //     System.out.println(ostrich.getHeads());

    //     ostrich.setHeads(3);
    //     System.out.println(ostrich.getHeads());
    // }

    



}