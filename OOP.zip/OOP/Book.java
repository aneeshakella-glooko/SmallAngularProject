public class Book {

    private Author author;
    private String title;
    public int yearPublished;
    
    public Book(Author bookAuthor, String bookTitle, int yearPublished)

    {
        this.author = bookAuthor;
        this.title = bookTitle;
        this.yearPublished = yearPublished;
    }

    public void printDetails(){
        System.out.println (this.author);
        System.out.println(this.title);
        System.out.println(this.yearPublished);
    }

    public Author getAuthor(){
        return this.author;
    }

    public String getTitle(){
        return this.title;
    }
    
    public int getYearPublished(){
        return this.yearPublished;
    }

    public void setAuthor(Author author){
        this.author = author;
    }

    public void setTitle(String title){
        this.title = title;
    }



    public void setYearPublished(int yearPublished){
        if( yearPublished > 2018 || yearPublished < 1990){
            this.yearPublished = 0;
        } else{
            this.yearPublished = yearPublished;
        }
    }



    public static void main(String [] args){
        Author JKRowling = new Author("J.K.Rowling", "jkrowling@gmail.com", 'F');
        Book HarryPotter = new Book (JKRowling, "Harry_Potter", 2001);
        System.out.println (HarryPotter.getAuthor().getEmail());
        System.out.println (HarryPotter.getAuthor().getName());
        System.out.println (HarryPotter.getAuthor().getGender());

        System.out.println (HarryPotter.getTitle());
        System.out.println (HarryPotter.getYearPublished());
        HarryPotter.setYearPublished(1984);
        System.out.println(HarryPotter.getYearPublished());
        
    }



}
